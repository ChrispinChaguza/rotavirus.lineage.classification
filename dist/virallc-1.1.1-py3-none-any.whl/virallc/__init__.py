""" ViralLC: A package rapid assignment of viral lineage nomenclature"""

__version__ = "1.1.1"

